var WWH_host_div = document.createElement("div");
WWH_host_div.id = "WWH_host_div";
var shadowRoot = WWH_host_div.attachShadow({mode: 'closed'});
var pop_up_div = document.createElement("DIV");
pop_up_div.id = "WWH_pop_up_div";
var internal_div = document.createElement("DIV");
internal_div.id = "WWH_internal_div"
var pre_text = document.createElement("PRE");
internal_div.appendChild(pre_text);
pop_up_div.appendChild(internal_div);
shadowRoot.appendChild(pop_up_div);

document.addEventListener("DOMContentLoaded", function(event) {
                          document.body.appendChild(WWH_host_div);
});

document.addEventListener("click", function(event) {
                          pop_up_div.style.visibility = 'hidden';
});

document.addEventListener("dblclick", function(event) {
    if (window.getSelection() && document.activeElement.tagName.toLowerCase() != "input" && document.activeElement.tagName.toLowerCase() != "textarea") {
        var text = window.getSelection().toString();
        if (text != "") {
            pop_up_div.style.visibility = 'visible';
            pop_up_div.style.left = (event.pageX + 15).toString() + "px";
            pop_up_div.style.top = event.pageY.toString() + "px";
            pre_text.textContent = "";
            safari.extension.dispatchMessage(text);
        }
    }
});

safari.self.addEventListener("message", extensionMessageHandler);

function extensionMessageHandler(event) {
    if (event.name === "queryResponse") {
        pop_up_div.style.visibility = 'visible';
        pre_text.textContent = event.message["responseText"];
        var div_rect = pop_up_div.getBoundingClientRect();
        if (div_rect.x + div_rect.width > document.documentElement.clientWidth) {
            pop_up_div.style.left = (document.documentElement.clientWidth - div_rect.width - 5).toString() + "px";
        }
        if (div_rect.y + div_rect.height > document.documentElement.clientHeight) {
            pop_up_div.style.top = (document.documentElement.clientHeight - div_rect.height + window.scrollY - 5).toString() + "px";
        }
    }
}

document.addEventListener("contextmenu", handleContextMenu, false);
function handleContextMenu(event) {
    if (window.getSelection() && document.activeElement.tagName.toLowerCase() != "input" && document.activeElement.tagName.toLowerCase() != "textarea") {
        var selectedText = window.getSelection().toString();
        safari.extension.setContextMenuEventUserInfo(event, { "selectedText": selectedText });
        pop_up_div.style.left = (event.pageX + 15).toString() + "px";
        pop_up_div.style.top = event.pageY.toString() + "px";
        pre_text.textContent = "";
    }
}
